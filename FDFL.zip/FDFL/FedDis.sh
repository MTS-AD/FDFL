for dataname in 'HAR' 'CAP' 'SEDFx'
do
      python FedDis_AE_V4.py --dataname $dataname
done